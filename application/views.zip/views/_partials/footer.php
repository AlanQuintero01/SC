<footer id="footer">
        <div class="container">
            <div class="d-flex">
                <div class="mr-auto p-2 d-flex align-items-end">
                    <p class="copyright mt-3">Copyright © Social Crowd MX</p>
                </div>
                <div class="ml-auto p-3 d-flex align-items-end">
                <div class="social">
                    <a target="_blank" href="https://www.facebook.com/SocialCrowdMx/"><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i></a>
                    <a target="_blank" href="https://twitter.com/socialcrowdmx"><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></a>
                    <a target="_blank" href="https://www.youtube.com/channel/UCfQR0ATA7ZYJT_8qvtDPi9A"><i class="fa fa-youtube-play fa-2x" aria-hidden="true"></i></a>
                </div>
                </div>
            </div>
        </div>
    </footer>
