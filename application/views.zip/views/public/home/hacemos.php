  <!-- Services Section -->
  <section class="page-section" id="hacemos">
    <div class="container">
      <h2>¿QUÉ HACEMOS?</h2>
      <h4>NUESTRA VISIÓN</h3>
        <p>La Plataforma de Crowdfunding es un mecanismo mediante el cual las Empresas Sociales pueden obtener fondos en línea como una opción de financiamiento no tradicional a través de un esquema de aportaciones y recompensas, la cual fomentará e impulsará la cultura emprendedora.</p>
        <p>Actualmente, por la contingencia sanitaria en el mundo y en México, Social Crowd Mx, apoya a los cuerpos de salud, sanitario y de seguridad para obtener los recursos y donas Equipo de Protección Personal.</p>        
  </section>