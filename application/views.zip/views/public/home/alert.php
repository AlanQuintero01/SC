<div class="col-md-3 alerta p-2" id="div">
  <div class="alert alert-primary alert-dismissible fade show" role="alert">
    <h6>Esta plataforma apoya en emergencia sanitaria a</h6>
    <mark class="text-white color2 h6">personal médico, sanitario y de seguridad</mark>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</div>